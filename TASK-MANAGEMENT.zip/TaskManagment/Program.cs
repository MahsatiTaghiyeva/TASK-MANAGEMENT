﻿using TaskManagment.Enums;
using TaskManagment.Extensions;
using TaskManagment.Models;
using TaskManagment.Services;

UserService userService = new UserService();
TaskService taskService = new TaskService();

while (true)
{
    Console.WriteLine();
    Console.WriteLine("===== TASK MANAGEMENT =====");
    Console.WriteLine("1. Add User");
    Console.WriteLine("2. Find User By Email");
    Console.WriteLine("3. Add Task");
    Console.WriteLine("4. Find Task By Title");
    Console.WriteLine("5. Find Tasks By Status");
    Console.WriteLine("6. Delete Task By ID");
    Console.WriteLine("7. Find Tasks By Priority");
    Console.WriteLine("8. Change Task Priority");
    Console.WriteLine("9. Assign Task To User");
    Console.WriteLine("10. Get Tasks By User");
    Console.WriteLine("11. Show All Tasks");
    Console.WriteLine("12. Show Task Time");
    Console.WriteLine("0. Exit");

    Console.Write("Choose: ");
    string choice = Console.ReadLine()!;

    try
    {
        switch (choice)
        {
            case "1":
                Console.Write("Enter user name: ");
                string name = Console.ReadLine()!;

                Console.Write("Enter email: ");
                string email = Console.ReadLine()!;

                User user = new User(name, email);

                userService.AddUser(user);

                Console.WriteLine("User added successfully.");
                Console.WriteLine(user);
                break;

            case "2":
                Console.Write("Enter email: ");
                string searchEmail = Console.ReadLine()!;

                User foundUser =
                    userService.FindByEmail(searchEmail);

                Console.WriteLine(foundUser);
                break;

            case "3":
                Console.Write("Enter title: ");
                string title = Console.ReadLine()!;

                Console.Write("Enter description: ");
                string description = Console.ReadLine()!;

                Console.Write("Enter deadline (yyyy-MM-dd HH:mm): ");
                DateTime deadline =
                    DateTime.Parse(Console.ReadLine()!);

                Console.Write("Enter status (ToDo/InProgress/Done): ");
                string statusInput = Console.ReadLine()!;

                if (!Enum.TryParse<TaskStatus>(
                    statusInput,
                    true,
                    out TaskStatus status))
                {
                    Console.WriteLine("Invalid status.");
                    break;
                }

                Console.Write("Enter priority (Low/Medium/High): ");
                string priorityInput = Console.ReadLine()!;

                if (!Enum.TryParse<TaskPriority>(
                    priorityInput,
                    true,
                    out TaskPriority priority))
                {
                    Console.WriteLine("Invalid priority.");
                    break;
                }

                MyTask task = new MyTask(
                    title,
                    description,
                    deadline,
                    status,
                    priority);

                taskService.AddTask(task);

                Console.WriteLine("Task added successfully.");
                Console.WriteLine(task);
                break;

            case "4":
                Console.Write("Enter task title: ");
                string findTitle = Console.ReadLine()!;

                MyTask foundTask =
                    taskService.FindByTitle(findTitle);

                Console.WriteLine(foundTask);
                break;

            case "5":
                Console.Write("Enter status: ");
                string findStatus = Console.ReadLine()!;

                List<MyTask> statusTasks =
                    taskService.FindByStatus(findStatus);

                foreach (var taskItem in statusTasks)
                {
                    Console.WriteLine(taskItem);
                }

                break;

            case "6":
                Console.Write("Enter task ID: ");
                int deleteId = int.Parse(Console.ReadLine()!);

                taskService.DeleteById(deleteId);

                Console.WriteLine("Task deleted successfully.");
                break;

            case "7":
                Console.Write("Enter priority: ");
                string findPriority = Console.ReadLine()!;

                List<MyTask> priorityTasks =
                    taskService.FindByPriority(findPriority);

                foreach (var taskItem in priorityTasks)
                {
                    Console.WriteLine(taskItem);
                }

                break;

            case "8":
                Console.Write("Enter task ID: ");
                int taskId = int.Parse(Console.ReadLine()!);

                Console.Write("Enter new priority (Low/Medium/High): ");
                string newPriorityInput = Console.ReadLine()!;

                if (!Enum.TryParse<TaskPriority>(
                    newPriorityInput,
                    true,
                    out TaskPriority newPriority))
                {
                    Console.WriteLine("Invalid priority.");
                    break;
                }

                taskService.ChangePriority(
                    taskId,
                    newPriority);

                Console.WriteLine("Priority changed successfully.");
                break;

            case "9":
                Console.Write("Enter task ID: ");
                int assignTaskId =
                    int.Parse(Console.ReadLine()!);

                Console.Write("Enter user ID: ");
                int assignUserId =
                    int.Parse(Console.ReadLine()!);

                taskService.AssignTaskToUser(
                    assignTaskId,
                    assignUserId);

                Console.WriteLine(
                    "Task assigned successfully.");

                break;

            case "10":
                Console.Write("Enter user ID: ");
                int userId =
                    int.Parse(Console.ReadLine()!);

                List<MyTask> userTasks =
                    taskService.GetTasksByUser(userId);

                foreach (var userTask in userTasks)
                {
                    Console.WriteLine(userTask);
                }

                break;

            case "11":
                if (TaskService.Tasks.Length == 0)
                {
                    Console.WriteLine("No tasks available.");
                    break;
                }

                foreach (var taskItem in TaskService.Tasks)
                {
                    Console.WriteLine(taskItem);
                }

                break;

            case "12":
                Console.Write("Enter task ID: ");
                int timeTaskId =
                    int.Parse(Console.ReadLine()!);

                MyTask timeTask = null!;

                foreach (var taskItem in TaskService.Tasks)
                {
                    if (taskItem.Id == timeTaskId)
                    {
                        timeTask = taskItem;
                        break;
                    }
                }

                if (timeTask == null)
                {
                    throw new NotFoundException(
                        $"Task with ID {timeTaskId} not found.");
                }

                Console.WriteLine(
                    $"Remaining time: {timeTask.GetRemainingTime()}");

                Console.WriteLine(
                    $"Allocated time: {timeTask.GetAllocatedTime()}");

                break;

            case "0":
                Console.WriteLine("Goodbye!");
                return;

            default:
                Console.WriteLine("Invalid choice.");
                break;
        }
    }
    catch (ConflictException ex)
    {
        Console.WriteLine($"Conflict: {ex.Message}");
    }
    catch (NotFoundException ex)
    {
        Console.WriteLine($"Not Found: {ex.Message}");
    }
    catch (FormatException)
    {
        Console.WriteLine("Invalid input format.");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error: {ex.Message}");
    }
}